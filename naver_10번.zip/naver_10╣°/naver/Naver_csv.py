import requests
import urllib.parse
import re
import pandas as pd
from datetime import datetime
from bs4 import BeautifulSoup

# 🔐 Naver API 인증 정보
client_id = "64g43aYmdLhFMenUVVVZ"
client_secret = "LrXCNWZHsp"

# ✅ CSV 파일 읽기
try:
    df = pd.read_csv("JOBKOREA10hehe.csv")
    corp_name_list = df["기업명"].dropna().unique().tolist()[:500]
    print(f"✅ CSV 파일에서 {len(corp_name_list)}개 기업명을 불러왔습니다.")
except Exception as e:
    print(f"❌ CSV 파일 읽기 실패: {e}")
    corp_name_list = []

# ✅ 전체 뉴스 저장 리스트
all_news = []

# ✅ 기업명별로 뉴스 수집
for corp in corp_name_list:
    try:
        encoded = urllib.parse.quote(corp)
        url = f"https://openapi.naver.com/v1/search/news.xml?query={encoded}&display=10&start=1&sort=sim"

        headers = {
            "X-Naver-Client-Id": client_id,
            "X-Naver-Client-Secret": client_secret,
        }

        res = requests.get(url, headers=headers)

        if res.status_code == 200:
            soup = BeautifulSoup(res.text, "lxml")
            items = soup.find_all("item")
            for item in items:
                all_news.append({
                    "기업명": corp,
                    "제목": re.sub(r"<.*?>", "", item.title.text) if item.title else "",
                    "설명": re.sub(r"<.*?>", "", item.description.text) if item.description else "",
                    "링크": item.link.text if item.link else "",
                    "발행일": item.pubdate.text if item.pubdate else "",
                })
            print(f"✅ {corp} - 뉴스 {len(items)}건 수집됨")
        else:
            print(f"❌ {corp} - 요청 실패 (HTTP {res.status_code})")
    except Exception as ex:
        print(f"⚠️ {corp} - 예외 발생: {ex}")

# ✅ 결과 저장 (CSV)
if all_news:
    df_result = pd.DataFrame(all_news)
    now = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"naver_news_500_companies_{now}.csv"
    try:
        df_result.to_csv(filename, index=False, encoding="utf-8-sig")
        print(f"\n📁 뉴스가 CSV 파일로 저장되었습니다: {filename}")
    except Exception as e:
        print(f"\n❌ CSV 저장 실패: {e}")
else:
    print("\n⚠️ 수집된 뉴스 데이터가 없습니다.")
